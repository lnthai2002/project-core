package com.taglib.wdjsp.faqtool;

public class FaqRepositoryException extends Exception {
  
  public FaqRepositoryException() {
    super();
  }

  public FaqRepositoryException(String msg) {
    super(msg);
  }
}
