package com.taglib.wdjsp.faqtool;

public class CommandException extends Exception {
  
  public CommandException() {
    super();
  }

  public CommandException(String msg) {
    super(msg);
  }
}
