package com.taglib.wdjsp.mut;

public class OutlineTag extends OutlineBase {
    public int doStartTag () {
	return EVAL_BODY_INCLUDE;
    }
}
